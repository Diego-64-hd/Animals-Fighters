// Este es el DOM
const battleLog = document.getElementById("battle-log");

function escribirTexto(texto) {

    const mensaje = document.createElement("p");

    mensaje.textContent = texto;

    battleLog.appendChild(mensaje);
}

const texto = document.querySelector('.star');
let cargando = false;

document.addEventListener('keydown', (event) => {
  if (event.key === "Enter") {
  if (cargando) return;
  cargando = true;

  texto.textContent = '░░░░░░░░░░░░░░░░';
  texto.style.left = "30%";

  let progreso = 0;
  const intervalo = setInterval(() => {
    progreso++;
    const lleno = '█'.repeat(progreso);
    const vacio = '░'.repeat(16 - progreso);
    texto.textContent = lleno + vacio;

    if (progreso >= 16) {
      clearInterval(intervalo);
      cargando = false;
     document.getElementById('battle-1').style.display = 'none';
      document.getElementById('modos').style.display = 'block';
     }
   }, 80);
 }
});

function selection() {
   texto.textContent = '░░░░░░░░░░░░░░░░';
  texto.style.left = "30%";

  let progreso = 0;
  const intervalo = setInterval(() => {
    progreso++;
    const lleno = '█'.repeat(progreso);
    const vacio = '░'.repeat(16 - progreso);
    texto.textContent = lleno + vacio;

    if (progreso >= 16) {
      clearInterval(intervalo);
      cargando = false;
     document.getElementById('modos').style.display = 'none';
      document.getElementById('seleccionpj').style.display = 'block';
     }
   }, 80);
}